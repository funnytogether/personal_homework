Neo4j FoodMart dataset
======================

A dataset for use with Neo4j, based on the classic Food Mart SQL dataset.
It currently includes the product, customer and sales data.

To load the dataset, use the included Cypher script. E.g.:

    ./bin/neo4j-shell < foodmart-import.cyp
